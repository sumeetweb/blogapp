from django.shortcuts import render
from django.core.mail import send_mail
from .models import Post
from django.views.generic import ListView, DetailView

# Create your views here.

class HomePageView(ListView):
    model = Post
    template_name = 'home.html'

class PostDetailView(DetailView):
    model = Post
    template_name = 'post_detail.html'

def AboutPageView(request):
    return render(request, 'about.html')

def ContactPageView(request):
    if request.method == 'POST':
        name = request.POST['cName']
        email = request.POST['cEmail']
        from_email = name + '<' + email + '>'
        message = request.POST['cMessage']
        send_mail(
        name,
        message,
        from_email,
        ['admin@developer.com'],
        )
        return render(request, 'contact.html', {"name" : name})
    else:
        return render(request, 'contact.html', {})